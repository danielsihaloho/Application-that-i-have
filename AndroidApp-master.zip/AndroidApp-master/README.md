# AndroidApp
This repository contains andriod apps developed by myself for learning purposes.
All the apps are developed in [Android Studio](https://developer.android.com/studio/index.html).

# Project List:
## 1. Calculator
### * Introduction:
This app implements a simple calculator for addition, subtraction, multiplication, division, and modulus.

## 2. Movie List
### * Introduction:
This app displays a list of movies.
