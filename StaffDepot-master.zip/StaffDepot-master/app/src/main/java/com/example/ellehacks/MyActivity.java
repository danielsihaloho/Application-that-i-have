package com.example.ellehacks;



/**
 * Created by ANUPYA on 2018-02-03.
 */

public class MyActivity {
    public static void main(String[] args) {
        /*AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "database-name").build();*/
    }
}
