CREATE TABLE leaderboard (rowid INTEGER PRIMARY KEY, email TEXT, points INT);

INSERT INTO leaderboard (email, points) VALUES ('anupya@hotmail.ca', 10);
INSERT INTO leaderboard (email, points) VALUES ('stephanie@gmail.com', 20);
INSERT INTO leaderboard (email, points) VALUES ('anemme@live.ca', 40);
INSERT INTO leaderboard (email, points) VALUES ('fatum@yahoo.com', 30);
INSERT INTO leaderboard (email, points) VALUES ('hui@yahoo.com', 100);
INSERT INTO leaderboard (email, points) VALUES ('flora@yahoo.com', 80);
