# StaffDepot

An Android app to help train HomeDepot sales associates using in-app games and quizzes. Built with Android Studio and Sqlite. ElleHacks 2018.

What I did: Built the database that contains all the sales associate profiles (email of the sales associates, points earned by answering quizzes) using Sqlite.

This project is incomplete due to running out of time :(
