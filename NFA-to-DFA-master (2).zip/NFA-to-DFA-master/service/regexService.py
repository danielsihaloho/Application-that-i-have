# class regex:
#     self.alphabet = [chr(i) for i in range(65, 91)]
#     self.alphabet.extend([chr(i) for i in range(97, 123)])
#     self.alphabet.extend([chr(i) for i in range(48, 58)])
#
#
# def regex_to_dfa(self,regex=str):
#     pre_char = '::e::'
#     for char in regex:
#         if char in self.alphabet:
#             if pre_char == '::e::':
#
