# AndroidFingerprintAPI

This is the Android Studio project that I work on in the article "Securing Your Android Apps with the Fingerprint API".
https://www.sitepoint.com/securing-your-android-apps-with-the-fingerprint-api/
