# Ball-in-maze-an-Android-game
An Android app developed in Android Studio
Using gravity sensor to move the ball by tilting phone. Moving the ball to destination in designed maze.
