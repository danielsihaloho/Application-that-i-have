package com.saucelabs.TestRules;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by mehmetgerceker on 12/22/15.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface Retry {
}
