Android App created in Android Visual Studio

The build version (apk) can be found in app/build/outputs/apk  - you can install it in your android device to see it in action.

The questions are hardcoded for testing purposes and will be found in separate files or will be downloaded from a webserver in MyServerData class.

This App is intended to be used as a sketch for an Android Multiple Choice Questions App.

Any constructive feedback is welcomed ! Thanks !