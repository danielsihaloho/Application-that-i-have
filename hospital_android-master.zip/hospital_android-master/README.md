# hospital_android
The Hospital Management system app has been developed using Android Studio for Android devices. This android app tries to give an overall view of the different elements that can interact in a Hospital system.
