# Movie-Database-Android-Application
A movie database application for android. Store all the information for your home movie collection in this database.
