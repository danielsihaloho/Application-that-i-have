sample-android-cordova-webview
==============================

A Sample for running a cordova app in an Android Webview - with Android Studio and gradle
