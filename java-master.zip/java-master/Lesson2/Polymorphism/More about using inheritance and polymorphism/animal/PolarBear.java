package animal;

public class PolarBear extends Bear {
    
    public PolarBear () {
        super("white");
        
    }

    public void eat () {
        super.eat();
    }
    
}