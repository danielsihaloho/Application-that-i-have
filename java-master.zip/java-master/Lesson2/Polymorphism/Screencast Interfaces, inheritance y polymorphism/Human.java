public class Human{
	protected String name;

	public Human(String name){
		this.name = name;
	}

	public void printName(){
		System.out.println(name);
	}
}