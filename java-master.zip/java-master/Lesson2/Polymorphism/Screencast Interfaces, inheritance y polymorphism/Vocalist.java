public interface Vocalist{
	public void sing();
}