public class F1Car extends Car {
    
    public F1Car(int topSpeed) {
	    super(topSpeed);
    }
    
    public void printDescription() {
	    System.out.println("F1 Car");
    }
}