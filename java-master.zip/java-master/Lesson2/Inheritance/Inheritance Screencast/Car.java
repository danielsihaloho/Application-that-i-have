public class Car {
    public int topSpeed;
    
    public Car(int topSpeed) {
        this.topSpeed = topSpeed;
    }
    
    public int getTopSpeed() {
        return topSpeed;
    }
    
    public void printDescription() {
        System.out.println("Car");
    }
}
