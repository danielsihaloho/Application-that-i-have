public interface Vehicle {
    public String getTransportType();
    public boolean hasWheels();
}
