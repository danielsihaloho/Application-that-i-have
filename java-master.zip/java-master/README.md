# java
Gain entry-level skills and knowledge in Java fundamentals and an intro to Android Studio for a strong foundation in Android Apps.
