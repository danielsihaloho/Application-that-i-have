/**
* Main class of the Java Program
*/
public class Main{
	public static void main(String[] args) {
		int grade =85;
		if(grade > 70){
			System.out.println("Congratulations!");
		}else{
			System.out.println("You should work harder");
		}
			
				
	}
}
