/**
 * Main class of the Java program
 */

public class Main {
    
    public static void main(Strings[] args){
        
        int number = 1;
        
        while(number <= 5){
            System.out.println(number);
            number = number + 1;
        }
    }
}