public class Main{
	public static void main(String[] args) {
		//basic example
		System.out.println("Basic example");
		for (int sequence = 0; sequence <= 10; sequence++ /* sequence = sequence + 2*/) {
			System.out.println(sequence);
		}
	}
}