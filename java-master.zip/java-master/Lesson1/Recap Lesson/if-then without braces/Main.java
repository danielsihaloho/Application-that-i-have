public class Main{
	public static void main(String[] args) {
		int number = 10;
		if (number > 10){
			System.out.println("The number is greater than 10");
			System.out.println("You should enter a number smaller or equal than 10");
		}
	}
}