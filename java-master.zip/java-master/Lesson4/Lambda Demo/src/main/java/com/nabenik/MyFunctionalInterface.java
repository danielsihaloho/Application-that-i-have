package com.nabenik;

/**
 *
 * @author tuxtor
 */
public interface MyFunctionalInterface {
    abstract void doSomethingFunctional(String txt);
}
